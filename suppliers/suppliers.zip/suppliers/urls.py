
from django.urls import path, include
from rest_framework.routers import DefaultRouter

from supplierspayment.views import SuppliersPaymentView
from .views import SuppliersView
router = DefaultRouter()
router.register(r'', SuppliersView, basename='')


urlpatterns = [
    path('', include(router.urls)),

    path('list_suppliers_account/', SuppliersPaymentView.as_view({'get': 'list_suppliers_account'}),
         name='list_suppliers_account'),


]
