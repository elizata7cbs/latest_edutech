
# Register your models here.
from django.contrib import admin

from suppliers.models import Suppliers


# Register your models here.
admin.site.register(Suppliers)
