import os
from decimal import Decimal

import django
from django.db.models.signals import post_save
from django.dispatch import receiver

from fee.models import StudentFeeCategories
from feecategories.models import FeeCategories, VirtualAccount
from feecollections.models import FeeCollection, Transaction
from suppliers.models import Suppliers, SuppliersAccount
from supplierspayment.models import SuppliersPayment

# Manually configure Django settings
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'edutech_payment_engine.settings')
django.setup()
import os
import random

from django.core.mail import send_mail
from requests import Response
from rest_framework import status

from edutech_payment_engine.settings import BASE_DIR
from authuser.models import OTP
from datetime import timedelta, datetime
from django.utils import timezone

from students.models import Students, StudentAccount


class Helpers:

    def generateSchoolId(self):
        pass

    # def savecode(self, **kwargs):
    #     last_fee_collection = FeeCollections.objects.order_by('-id').first()
    #     if last_fee_collection:
    #         last_feecode = last_fee_collection.feecode
    #         last_number = int(last_feecode.split('-')[-1])
    #         next_number = last_number + 1
    #         next_feecode = str(next_number).zfill(2)
    #         feecode = f'{last_feecode[:3]}-{last_feecode[4:6]}-{next_feecode}'
    #     else:
    #         # If no fee collections exist yet, use the default income code
    #         feecode = '001-01-01'  # Modify as needed
    #
    #     # Call serializer's save method with the calculated feecode
    #     return super().save(feecode=feecode, **kwargs)

    def generateUniqueId(self, schoolCode, admNumber):
        unique = f'{schoolCode}-{admNumber}'
        return str(unique)

    def generatecategorycode(self, name, description):
        categorycode = f'{name}-{description}'
        return categorycode

    def create_student_fee_categories(self):
        """
        Function to create new entries in StudentFeeCategories
        based on the associated FeeCategories.
        """
        # Retrieve all FeeCategories objects
        fee_categories = FeeCategories.objects.all()

        # Iterate over each FeeCategories object
        for fee_category in fee_categories:
            # Create a new StudentFeeCategories entry for each FeeCategories
            StudentFeeCategories.objects.create(
                student=fee_category.student,
                fee_category=fee_category,
                amount=fee_category.amount
            )

    def generate_reference(self, paymentmode, payment_date):
        reference = f'{paymentmode}-{payment_date}'
        return reference

    def calculate_balance(self, debit, credit):
        # Calculate the balance before saving
        balance = debit - credit
        return balance

    def generateUniqueexpenseid(self):
        pass

    def generateUniquefeepaymentid(self):
        pass

    # Create feecategories accounts
    @receiver(post_save, sender=FeeCategories)
    def create_virtual_account(sender, instance, created, **kwargs):
        if created:
            VirtualAccount.objects.create(category=instance)

    # credit feecategories account when selected
    @receiver(post_save, sender=StudentFeeCategories)
    def credit_fee_categories_virtual_account(sender, instance, created, **kwargs):
        if created:
            fee_category = instance.fee_category
            virtual_account, _ = VirtualAccount.objects.get_or_create(category=fee_category)
            virtual_account.credit += fee_category.amount
            virtual_account.save()

    # creating student virtual account
    @receiver(post_save, sender=Students)
    def create_student_account(sender, instance, created, **kwargs):
        if created:
            # Create a student account when a new student is created
            StudentAccount.objects.create(student=instance)

    #  debit  student account when feecategories is created
    @receiver(post_save, sender=StudentFeeCategories)
    def debit_student_account(sender, instance, created, **kwargs):
        if created:
            student = instance.student
            student_account, _ = StudentAccount.objects.get_or_create(student=student)
            student_account.debit += instance.fee_category.amount
            student_account.save()

    # credit student account when payment is made
    @receiver(post_save, sender=FeeCollection)
    def credit_student_account(sender, instance, created, **kwargs):
        if created:
            # Convert instance.amount_paid to Decimal
            amount_paid_decimal = Decimal(instance.amount_paid)

            # Fetch the student account associated with the student
            student_account = StudentAccount.objects.get(student=instance.student)

            # Update the credit balance of the student account
            student_account.credit += amount_paid_decimal
            student_account.save()

    # record debit  transaction

    @receiver(post_save, sender=StudentFeeCategories)
    def record_debit_transaction(sender, instance, created, **kwargs):
        if created:
            # Create a new transaction for fee category selection
            Transaction.objects.create(
                student=instance.student,
                description=f"Fee category selected: {instance.fee_category}",
                debit=instance.fee_category.amount,
                credit=0,
                balance=None  # You may need to calculate this based on other transactions
            )

    # record credit  transaction
    @receiver(post_save, sender=FeeCollection)
    def record_credit_transaction(sender, instance, created, **kwargs):
        if created:
            # Create a new transaction for fee payment
            Transaction.objects.create(
                student=instance.student,
                description=f"Fee payment made: {instance.reference}",
                debit=0,
                credit=instance.amount_paid,
                balance=None  # You may need to calculate this based on other transactions
            )
#creating supplier account
    @receiver(post_save, sender=Suppliers)
    def create_supplier_account(sender, instance, created, **kwargs):
        if created:
            # Create a student account when a new student is created
           SuppliersAccount.objects.create(supplier=instance)
#crediting supplier account
    @receiver(post_save, sender=SuppliersPayment)
    def credit_supplier_account(sender, instance, created, **kwargs):
        if created:
            # Convert instance.amount_paid to Decimal
            amount_paid_decimal = Decimal(instance.amount_paid)

            # Fetch the supplier account associated with the student
            supplier_account = SuppliersAccount.objects.get(supplier=instance.supplier)

            # Update the credit balance of the student account
            supplier_account.credit += amount_paid_decimal
            supplier_account.save()

#debit supplier account
    @receiver(post_save, sender=Suppliers)
    def debit_supplier_account(sender, instance, created, **kwargs):
        if created:
            # Convert instance.openingBalance to Decimal
            openingBalance = Decimal(instance.openingBalance)
            supplier_account, _ = SuppliersAccount.objects.get_or_create(supplier=instance)
            supplier_account.debit += openingBalance
            supplier_account.save()
    def otp(self, name, otp, email):
        try:
            email_content = f"""
            <html>
                <head>
                    <style>
                        font-size: 12px;
                    </style>
                </head>
                <body>
                    <p>Hello {name},</p>
                    <p style="font-size: 20px, color: black;">Use: <span class="otp" >{otp}</span></p>
                    <p>If you did not request this, please ignore. Do not share OTP with anyone.</p>
                </body>
            </html>
            """
            sent = send_mail(
                'Verification OTP',
                '',
                'no-reply@gmail.com',
                [email],
                fail_silently=False,
                html_message=email_content,
            )
            return sent

        except Exception as e:
            # response.setMessage(f"Error sending email: {str(e)}")
            sent = 0
            print(f"Error sending email: {str(e)}")
        return sent

    def generateotp(self):
        characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz"
        otp = ''.join(random.choice(characters) for _ in range(8))
        return otp

    def saveotp(self, otp, email):
        expiry_time = timezone.now() + timedelta(minutes=5)
        otpData = OTP(
            otp=otp,
            email=email,
            expirydate=expiry_time
        )
        otpData.save()
        return None

    def log(self, request):
        current_date = datetime.now().strftime('%Y.%m.%d')
        log_file_name = f"{current_date}-request.log"
        log_file_path = os.path.join(BASE_DIR, f'utils/logs/{log_file_name}')
        log_string = f"[{datetime.now().strftime('%Y.%m.%d %I.%M.%S %p')}] => method: {request.method} uri: {request.path} queryString: {request.GET.urlencode()} protocol: {request.scheme} remoteAddr: {request.META.get('REMOTE_ADDR')} remotePort: {request.META.get('REMOTE_PORT')} userAgent: {request.META.get('HTTP_USER_AGENT')}"
        if os.path.exists(log_file_path):
            mode = 'a'
        else:
            mode = 'w'
        with open(log_file_path, mode) as log_file:
            log_file.write(log_string + '\n')
